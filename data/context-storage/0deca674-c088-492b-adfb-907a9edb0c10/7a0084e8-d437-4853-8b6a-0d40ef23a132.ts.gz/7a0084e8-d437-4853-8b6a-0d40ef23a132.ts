/**
 * MCP Tools Registry
 * ==================
 *
 * Register all MCP tools with the server.
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { ListToolsRequestSchema, CallToolRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import Database from 'better-sqlite3';
import { TaskRegistry } from '../registry/TaskRegistry.js';
import { GitTracker } from '../registry/GitTracker.js';
import { createGetAvailableTasksTool } from './getAvailableTasks.js';
import { createClaimTaskTool } from './claimTask.js';
import { createUpdateProgressTool } from './updateProgress.js';
import { createCompleteTaskTool } from './completeTask.js';
import { createGetDashboardTool } from './getDashboard.js';
import { createGetAgentStatusTool } from './getAgentStatus.js';
import { agentConnectTool, handleAgentConnect } from './intelligence/agentConnect.js';
import { agentHeartbeatTool, handleAgentHeartbeat } from './intelligence/agentHeartbeat.js';
import { agentDisconnectTool, handleAgentDisconnect } from './intelligence/agentDisconnect.js';
import { getSwarmDashboardTool, handleGetSwarmDashboard } from './intelligence/getSwarmDashboard.js';
import { discoverEnvironmentTool, handleDiscoverEnvironment } from './discovery/discoverEnvironment.js';
import { uploadContextTool, handleUploadContext, searchContextTool, handleSearchContext, retrieveContextTool, handleRetrieveContext, getContextStatsTool, handleGetContextStats } from './discovery/contextTools.js';
import { getSystemHealthTool, handleGetSystemHealth } from './health/getSystemHealth.js';
import { agentCheckInTool, handleAgentCheckIn } from './keepintouch/agentCheckIn.js';
import { requestCompletionPermissionTool, handleRequestCompletionPermission } from './keepintouch/requestCompletionPermission.js';
import { logger } from '../utils/logger.js';

export function registerTools(
  server: Server,
  registry: TaskRegistry,
  gitTracker: GitTracker,
  db: Database.Database
): void {
  logger.info('🔧 Registering MCP tools...');

  // Task management tools (existing)
  const taskTools = [
    createGetAvailableTasksTool(registry),
    createClaimTaskTool(registry),
    createUpdateProgressTool(registry, gitTracker),
    createCompleteTaskTool(registry, gitTracker),
    createGetDashboardTool(registry, gitTracker),
    createGetAgentStatusTool(registry, gitTracker),
  ];

  // Intelligence tools (existing)
  const intelligenceTools = [
    { ...agentConnectTool, handler: (args: unknown) => handleAgentConnect(args, db) },
    { ...agentHeartbeatTool, handler: (args: unknown) => handleAgentHeartbeat(args, db) },
    { ...agentDisconnectTool, handler: (args: unknown) => handleAgentDisconnect(args, db) },
    { ...getSwarmDashboardTool, handler: (args: unknown) => handleGetSwarmDashboard(args, db) },
  ];

  // Discovery tools (NEW - PLUG-N-PLAY)
  const discoveryTools = [
    { ...discoverEnvironmentTool, handler: (args: unknown) => handleDiscoverEnvironment(args, db) },
    { ...uploadContextTool, handler: (args: unknown) => handleUploadContext(args, db) },
    { ...searchContextTool, handler: (args: unknown) => handleSearchContext(args, db) },
    { ...retrieveContextTool, handler: (args: unknown) => handleRetrieveContext(args, db) },
    { ...getContextStatsTool, handler: (args: unknown) => handleGetContextStats(args, db) },
  ];

  // Health tools (NEW - SELF-HEALING)
  const healthTools = [
    { ...getSystemHealthTool, handler: (args: unknown) => handleGetSystemHealth(args, db, './data/registry.db') },
  ];

  // Keep-in-Touch tools (NEW - COMPLETION GATING) ⭐
  const keepInTouchTools = [
    { ...agentCheckInTool, handler: (args: unknown) => handleAgentCheckIn(args, db) },
    { ...requestCompletionPermissionTool, handler: (args: unknown) => handleRequestCompletionPermission(args, db) },
  ];

  const allTools = [...taskTools, ...intelligenceTools, ...discoveryTools, ...healthTools, ...keepInTouchTools];

  // Register handler for listing tools
  server.setRequestHandler(ListToolsRequestSchema, async () => {
    return {
      tools: allTools,
    };
  });

  // Register handler for calling tools
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;
    const tool = allTools.find((t) => t.name === name);

    if (!tool) {
      throw new Error(`Unknown tool: ${name}`);
    }

    try {
      return await (tool.handler as any)(args || {});
    } catch (error) {
      logger.error(`Tool execution error for ${name}:`, error);
      return {
        content: [{
          type: 'text',
          text: JSON.stringify({ error: String(error) }, null, 2)
        }],
        isError: true
      };
    }
  });

  logger.info(`✅ ${allTools.length} MCP tools registered successfully (${taskTools.length} task + ${intelligenceTools.length} intelligence + ${discoveryTools.length} discovery + ${healthTools.length} health + ${keepInTouchTools.length} keep-in-touch).`);
}
